﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 蓝牙调试助手.Models
{
    public enum DeviceOperation
    {
        Connection = 1,
        Pair = 2,
        Unpair = 4
    }

}
