﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 蓝牙调试助手.Models
{
    public class PairingOperatingResults
    {
        /// <summary>
        /// 确认PIN码结果
        /// </summary>
        public bool ConfirmPinMatchResult { get; set; }
    }
}
